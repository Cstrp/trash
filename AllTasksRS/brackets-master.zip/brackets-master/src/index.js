module.exports = function check(str, bracketsConfig) {
  let back = bracketsConfig.map(el => el.join(''));
  for (let i = 0; i < back.length; ) {
    if (str.includes(back[i])) {
      str = str.replace(back[i], '');
      i = 0;
    }
    else i++
  }
  return str === '';
};