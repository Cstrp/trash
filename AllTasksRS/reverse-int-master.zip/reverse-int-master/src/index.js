module.exports = function reverse (n) { const arr = Math.abs(n); const result = arr.toString().split('').reverse().join(''); return result;};
