newFunction();
function newFunction() {
    module.exports = function toReadable(number) {
        const ones = [
            "",
            "one",
            "two",
            "three",
            "four",
            "five",
            "six",
            "seven",
            "eight",
            "nine",
            "ten",
            "eleven",
            "twelve",
            "thirteen",
            "fourteen",
            "fifteen",
            "sixteen",
            "seventeen",
            "eighteen",
            "nineteen",
        ];
        const seconddozen = [
            "",
            "ten",
            "twenty",
            "thirty",
            "forty",
            "fifty",
            "sixty",
            "seventy",
            "eighty",
            "ninety",
        ];
        if (number === 0) {
            return "zero";
        }
        const roundup = Math.floor(number / 100);
        const amoutNumbers = number % 100;
        let result = "";
        if (roundup > 0 && amoutNumbers > 0) {
            result += `${ones[roundup]} hundred `;
        } else if (amoutNumbers === 0) {
            result += `${ones[roundup]} hundred`;
            return result;
        }
        if (amoutNumbers > 0 && amoutNumbers < 20) {
            return `${result}${ones[amoutNumbers]}`;
        } else if (amoutNumbers > 0) {
            const tens = amoutNumbers / 10;
            if (amoutNumbers % 10 === 0) {
                result += `${seconddozen[tens]}`;
                return result;
            }
            result += `${seconddozen[Math.floor(tens)]} `;
            let Ones = amoutNumbers % 10;
            if (Ones > 0) {
                result += `${ones[Ones]}`;
            }
        }
        return result;
    };
}
