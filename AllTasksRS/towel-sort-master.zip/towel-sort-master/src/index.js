module.exports = function towelSort (matrix) {
    var result = [];
    if (typeof matrix === "undefiend") return result;
    for (var e = 0; e < matrix.length; e++) {
        if (e%2 === 0) {
            for (var element of matrix[e]) {
                result.push(element);
            }
        }
        else {
            for (var element of matrix[e].reverse()) {
                result.push(element);
            }
        }
    }
    if (result.length > 0) return result;
    else return [];
}
