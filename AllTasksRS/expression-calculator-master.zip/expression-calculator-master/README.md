# Expression calculator

## Task

Your task is to implement function, which calculates the result for any math expressions.
Write your solution in `src/index.js`

---

**Do not use `Function constructor` and `eval`**   

**Input:** String, that contain `(`, `)`, `+`, `-`, `*`, `/` and `space`. Brackets can have **any nasting depth**   
**Output:** Value of expression (Number)

---

## Prepare and test

- Install [Node.js](https://nodejs.org/en/)
- Clone this repository: `https://github.com/romacher/expression-calculator.git`
- Go to folder `expression-calculator`
- Run `npm install` in command line
- Run `npm test` in command line
- You will see the number of passing and failing tests

## Submit to [rs app](https://app.rs.school)
1. Open [rs app](https://app.rs.school) and login
2. Open `RS APP` and click `Auto Test`
3. Select your task (expression-calculator)
4. Press the submit button and enjoy

### Notes
1. We recommend you to use nodejs of version 14 or lower. If you using any of features that does not supported by node v10, score won't be submitted.
2. Please be sure that each of your test in limit of 30sec.
