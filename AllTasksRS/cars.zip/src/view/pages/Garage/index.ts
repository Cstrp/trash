import { Server_Response } from '@/data/Enum';
import { Item } from '@/view/components/garage/_index';
import { Modal } from '@/view/components/modal';
import { Template } from '@/view/template';
import { GarageWrapper } from '@/view/components/garage';
import { GarageOptions } from '@/view/components/garage/options';
import { ICar, ICreateCar, IUpdateCar } from '@/data/Interfaces/ICar';
import { IWinner } from '@/data/Interfaces/IWinner';
import { IData } from '@/data/Interfaces/IData';
import { car, allCars, createCar, updateCar, removeCar } from '@/data/Api/_car';
import { winner, createWinner, updateWinner, removeWinner } from '@/data/Api/_winner';
import { generateRandomCars } from '@/data/Utils/helper';

class Garage extends Template {
  private modal!: Modal;

  private readonly options!: GarageOptions;

  private wrapper!: GarageWrapper;

  private pageNumber: number = 1;

  public constructor(parent: HTMLElement) {
    super(parent, 'section', 'garage_section');
    this.getCars(this.pageNumber);

    this.options = new GarageOptions(this.element);

    this.options.create = async (item) => {
      await this.createCar(item);
      await this.getCars(this.pageNumber);
    };

    this.options.update = (prop) => this.updateCar(prop);
    this.options.allStart = () => this.allStart();
    this.options.allStop = () => this.reset();
    this.options.generate = () => this.generate();

    this.wrapper = new GarageWrapper(this.element);
    this.wrapper.removeCar = (id) => this.removeCar(id);
    this.wrapper.updateCar = (id) => this.getCar(id);
    this.wrapper.updatePage = (counter) => {
      this.pageNumber = counter;
      this.getCars(counter);
    };
  }

  private async getCar(id: number): Promise<void> {
    const item = await car(id);

    if (item) this.options.updateState(item);
  }

  private async getCars(counter: number): Promise<void> {
    const data = await allCars(counter);

    if (data) {
      const arr: ICar[] = data.cars;
      const length: string = data.count;

      this.wrapper.addItem(arr, length);

      this.wrapper.pagination.updateNextBtn(this.pageNumber, +length, 7);

      if (!arr) {
        this.wrapper.pagination.removeElement();
      }
    }
  }

  private async createCar(item: ICreateCar | null, callback?: Array<{ name: string; color: string }>): Promise<void> {
    if (item) {
      await createCar(item);
      await this.getCars(this.pageNumber);
    }

    if (callback) {
      const data: IData[] = callback
        .map((item) => ({
          name: item.name,
          color: item.color,
          speed: 0,
          time: 0,
          wins: 0,
        }))
        .reverse() as IData[];

      const totalCreate = data.map(async (item) => {
        await createCar(item);
      }) as Promise<void>[];

      Promise.all(totalCreate).then(() => {
        this.options;
      });
    }
  }

  private async updateCar(item: IUpdateCar): Promise<void> {
    await updateCar(item);
    await this.getCars(this.pageNumber);
  }

  private async removeCar(id: number): Promise<void> {
    await removeCar(id);
    await removeWinner(id);
    await this.getCars(this.pageNumber);
  }

  private async allStart(): Promise<void> {
    this.options.button.race.setDisable(true);
    this.options.button.generate.setDisable(true);

    const res: Promise<Item>[] = this.wrapper.cars.map(async (item) => {
      await item.startEngine(item.car.id);
      item.allDisabled();

      return item;
    });

    const winner = await Promise.race(res);

    const data: IData = <IData>{
      id: winner.car.id as number,
      name: winner.car.name,
      color: winner.car.color,
      speed: +(winner.speed / 1000).toFixed(2),
      time: +(winner.speed / 1000).toFixed(2),
      wins: 1,
    };

    this.modal = new Modal(this.element, data);
    this.options.button.reset.removeDisable();
    setTimeout(() => this.modal.removeElement(), 1500);

    await this.winnersProp(data);
  }

  private async createWinner(item: IData): Promise<void> {
    const obj: IWinner = {
      id: item.id,
      wins: 1,
      time: item.speed,
    };

    await createWinner(obj);
  }

  private async updateWinner(item: IData): Promise<void> {
    const obj: IWinner = {
      id: item.id,
      wins: item.wins,
      time: item.speed,
    };

    await updateWinner(obj);
  }

  private async winnersProp(item: IData): Promise<void> {
    const data = await winner(item.id);

    if (data.status === Server_Response.success) {
      data.result.wins += 1;
      item.wins = data.result.wins;

      await this.updateWinner(item);
    } else {
      await this.createWinner(item);
    }
  }

  private async generate(): Promise<void> {
    this.options.button.race.setDisable(true);
    this.options.button.generate.setDisable(true);

    await this.createCar(null, generateRandomCars());
  }

  private reset(): void {
    this.options.button.reset.setDisable(true);

    const totalReset = this.wrapper.cars?.map(async (item) => {
      await item.stopEngine(item.car.id as number);
    });

    Promise.all(totalReset).then(() => {
      this.options.button.race.removeDisable();
      this.options.button.generate.removeDisable();
    });
  }
}

export { Garage };
