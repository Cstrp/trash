import { WinnersWrapper } from '@/view/components/winners';
import { Template } from '@/view/template';
import { allWinners } from '@/data/Api/_winner';

class Winners extends Template {
  private wrapper = new WinnersWrapper(this.element);

  private pageNumber: number = 1;

  public constructor(parent: HTMLElement) {
    super(parent, 'section', 'winners_section');
    this.getAll();

    this.wrapper.update = (counter: number) => {
      this.pageNumber = counter;
      this.getAll(this.pageNumber);
    };

    this.wrapper.sortItem = (item: string, order: string) => {
      this.getAll(this.pageNumber, item, order);
    };
  }

  public async getAll(item: number = 0, sortItem: string = 'id', itemOrder: string = 'ASC'): Promise<void> {
    const data = await allWinners(item, sortItem, itemOrder);
    const result = +data.count;

    this.wrapper.pagination.updateNextBtn(this.pageNumber, result, 5);
    this.wrapper.addItem(data);
  }
}

export { Winners };
