import { AppPage } from '@/data/Enum';
import { Footer } from '@/view/components/footer';
import { get, set } from '@/data/Utils/storage';
import { Error } from '@/view/pages/Error';
import { Header } from '@/view/components/header';
import { Garage } from '@/view/pages/Garage';
import { Winners } from '@/view/pages/Winners';
import { Template } from '@/view/template';

class App {
  private static element: HTMLElement = document.body;

  private static defaultID = 'app';

  private header: Header;

  private footer!: Footer;

  private err!: Error;

  private static init(id: string) {
    const app = document.querySelector(`#${App.defaultID}`);

    if (app) app.remove();

    let page: Template | null;

    switch (id) {
      case AppPage.garage:
        page = new Garage(App.element);
        break;
      case AppPage.winners:
        page = new Winners(App.element);
        break;
      default:
        page = new Garage(App.element);
    }

    if (page) {
      const html = page.render();

      html.id = App.defaultID;
      App.element.append(html);
    }
  }

  public constructor() {
    this.header = new Header(App.element);
  }

  private router() {
    const echoLocation = async () => {
      const hash = window.location.hash.replace('#', '/').slice(1);

      switch (hash) {
        case AppPage.garage:
          App.init(AppPage.garage);
          break;
        case AppPage.winners:
          App.init(AppPage.winners);
          break;
        default:
          App.init(AppPage.garage);
      }

      if (hash !== AppPage.garage && hash !== AppPage.winners) {
        this.err = new Error(App.element);
      }

      if (this.footer) {
        this.footer.removeElement();
      }

      this.footer = new Footer(App.element);

      return hash;
    };

    window.onpopstate = () => echoLocation();
  }

  private storage() {
    const storage = get('page');

    if (storage) {
      App.init(storage);
    } else {
      App.init(AppPage.garage);
    }

    window.onbeforeunload = () => set('page', window.location.hash.slice(1));
  }

  public render() {
    this.storage();
    this.router();
  }
}

export { App };
