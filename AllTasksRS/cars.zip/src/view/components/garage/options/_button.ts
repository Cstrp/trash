import { Template } from '@/view/template';
import { Button } from '@/view/components/UI/button';

class _Button extends Template {
  public allStart: () => void = () => {};

  public allStop: () => void = () => {};

  public generateCars: () => void = () => {};

  public race: Button;

  public reset: Button;

  public generate: Button;

  public constructor(parent: HTMLElement) {
    super(parent, 'div', 'garage-options__btn');

    this.race = new Button(this.element, 'race_btn', 'Race');
    this.race.onClickBtn = () => this.allStart();

    this.reset = new Button(this.element, 'reset_btn', 'Reset');
    this.reset.onClickBtn = () => this.allStop();

    this.generate = new Button(this.element, 'generate_btn', 'Generate');
    this.generate.onClickBtn = () => this.generateCars();
  }
}

export { _Button };
