import { Template } from '@/view/template';
import { Button } from '@/view/components/UI/button';
import { Input } from '@/view/components/UI/input';
import { ICreateCar } from '@/data/Interfaces/ICar';

class _Input extends Template {
  public create: (prop: ICreateCar) => void = () => {};

  private input!: Input;

  private inputColor!: Input;

  private button!: Button;

  public state = {
    name: '',
    color: '#000000',
  };

  public constructor(parent: HTMLElement, value: string, className: string) {
    super(parent, 'div', 'garage-options__input');

    const wrapper = new Template(this.element, 'div', 'garage-options__input-wrapper');

    this.input = new Input(wrapper.element, 'text', 'garage-options__input-name');
    this.input.getValue = (evt) => this.updateState('name', evt);

    this.inputColor = new Input(this.element, 'color', 'garage-options__input-color', '#000000');
    this.inputColor.getValue = (evt) => this.updateState('color', evt);

    this.button = new Button(this.element, 'garage-options__btn', `${value}`);
    this.button.element.setAttribute('disabled', '');
    this.button.onClickBtn = () => {
      this.create(this.state);
      this.resetInput();
    };

    this.element.classList.add(...className.split(' '));
  }

  public updateState = (key: keyof ICreateCar, evt: Event) => {
    const input = evt.target as HTMLInputElement;

    this.state[key] = input.value;

    this.button.element.toggleAttribute('disabled', this.state.name === '');
  };

  public resetInput(): void {
    this.state = {
      name: '',
      color: '#000000',
    };

    this.updateInput();
  }

  public updateInput(): void {
    (this.input.element as HTMLInputElement).value = this.state.name;
    (this.inputColor.element as HTMLInputElement).value = this.state.color;

    this.button.element.setAttribute('disabled', '');
  }
}

export { _Input };
