import { Template } from '@/view/template';
import { _Button } from '@/view/components/garage/options/_button';
import { _Input } from '@/view/components/garage/options/_input';
import { ICar, ICreateCar, IUpdateCar } from '@/data/Interfaces/ICar';

class GarageOptions extends Template {
  public allStart: () => void = () => {};

  public allStop: () => void = () => {};

  public generate: () => void = () => {};

  public create: (prop: ICreateCar) => void = () => {};

  public update: (prop: IUpdateCar) => void = () => {};

  public button!: _Button;

  public _input!: _Input;

  public constructor(parent: HTMLElement) {
    super(parent, 'div', 'wrapper');

    const createInput = new _Input(this.element, 'Create', 'garage__create');

    createInput.create = (prop) => this.create(prop);

    this._input = new _Input(this.element, 'Update', 'garage__update');
    this._input.create = () => this.update(this._input.state);

    this.button = new _Button(this.element);
    this.button.allStart = () => this.allStart();
    this.button.allStop = () => this.allStop();
    this.button.generateCars = () => this.generate();
  }

  public updateState(prop: ICar): void {
    this._input.state = prop;
    this._input.updateInput();
  }
}

export { GarageOptions };
