import { Server_Response } from '@/data/Enum';
import { _flagImg } from '@/data/Utils/_flag';
import { carImg } from '@/data/Utils/_car';
import { generateRandomColor } from '@/data/Utils/helper';
import { startEngine, stopEngine, switchMode } from '@/data/Api/_engine';
import { ICar } from '@/data/Interfaces/ICar';
import { Template } from '@/view/template';
import { Button } from '@/view/components/UI/button';
import { IEngine } from '@/data/Interfaces/IEngine';

const carWidth: number = 80;

class Item extends Template {
  public remove: (id: number) => void = () => {};

  public update: (id: number) => void = () => {};

  private startBtn!: Button;

  private stopBtn!: Button;

  private carImage!: Template;

  private finishImage!: Template;

  public car: ICar;

  public speed: number = 0;

  private anime!: Animation | null;

  public constructor(parent: HTMLElement, car: ICar) {
    super(parent, 'div', 'garage__item_wrapper');
    this.car = car;

    const itemTop = new Template(this.element, 'div', 'garage__item-top');

    const select = new Button(itemTop.element, 'select_btn', 'Select');

    select.onClickBtn = () => {
      if (car.id) this.update(car.id);
    };

    new Template(itemTop.element, 'span', null, car.name);

    const remove = new Button(itemTop.element, 'remove_btn', 'Remove');

    remove.onClickBtn = () => {
      if (car.id) this.remove(car.id);
      this.removeElement();
    };

    const field = new Template(this.element, 'div', 'garage__car_wrapper');

    const controls = new Template(field.element, 'div', 'garage__item_controls');

    this.startBtn = new Button(controls.element, 'start_btn', 'Start');
    this.startBtn.onClickBtn = () => {
      if (car.id) this.startEngine(car.id);
    };

    this.stopBtn = new Button(controls.element, 'stop_btn', 'Stop');
    this.stopBtn.onClickBtn = () => {
      if (car.id) this.stopEngine(car.id);
    };

    this.carImage = new Template(field.element, 'div', 'garage__item-car', `${carImg(car.color)}`);
    this.finishImage = new Template(field.element, 'div', 'garage__item-flag', `${_flagImg(generateRandomColor())}`);
  }

  public async startEngine(id: number): Promise<void> {
    const data = await startEngine(id);

    if (data.status === Server_Response.success) {
      this.updaters(true);

      const { result } = data;

      const time = result.distance / result.velocity;

      this.animateCar(time);
      await this.switchMode(result);
    }
  }

  public async stopEngine(id: number): Promise<void> {
    const res = await stopEngine(id);

    if (res.status === Server_Response.success) {
      this.updaters(false);
      this.speed = 0;
      this.anime?.cancel();
      this.carImage.element.style.left = `${carWidth}vw`;
    }
  }

  private async switchMode(mode: IEngine): Promise<void> {
    const driverMode = await switchMode(this.car.id);

    return new Promise((res) => {
      if (driverMode === Server_Response.server_err) {
        this.anime?.pause();
      }

      if (driverMode === Server_Response.success) {
        this.speed = Math.floor(mode.distance / mode.velocity);
        res();
      }
    });
  }

  private animateCar(time: number): void {
    this.anime = this.carImage.element.animate(
      [{ transform: 'translateX(0)' }, { transform: `translateX(calc(100% + ${carWidth}vw))` }],
      {
        duration: time,
        easing: 'linear',
      },
    );

    this.anime.play();
    this.anime.onfinish = () => {
      this.carImage.element.style.left = `calc(100% - ${carWidth}vw)`;
    };
  }

  public updaters(success: boolean = false): void {
    this.startBtn.setDisable(success);
    this.stopBtn.setDisable(!success);
  }

  public allDisabled(): void {
    this.startBtn.setDisable(true);
    this.stopBtn.setDisable(false);
  }
}

export { Item };
