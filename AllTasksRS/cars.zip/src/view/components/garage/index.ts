import { Template } from '@/view/template';
import { ICar } from '@/data/Interfaces/ICar';
import { Item } from '@/view/components/garage/_index';
import { Pagination } from '@/view/components/pagination';

class GarageWrapper extends Template {
  removeCar: (id: number) => void = () => {};

  updateCar: (id: number) => void = () => {};

  updatePage: (counter: number) => void = () => {};

  private wrapper!: Template;

  private title!: Template;

  public pagination!: Pagination;

  public cars: Item[] = [];

  constructor(parent: HTMLElement) {
    super(parent, 'div', 'wrapper');

    this.cars = [];

    this.title = new Template(this.element, 'h2', 'garage_title');

    this.pagination = new Pagination(this.element);
    this.pagination.updateCounter = (counter: number) => this.updatePage(counter);

    this.wrapper = new Template(this.element, 'div', 'cars_wrapper');
  }

  updateTitle(carsLength: string): void {
    this.title.element.innerHTML = `Garage (${carsLength})`;
  }

  private clean() {
    this.wrapper.element.innerHTML = '';
    this.cars = [];
  }

  public addItem(cars: ICar[], carsLength: string): void {
    this.clean();

    this.updateTitle(carsLength);

    this.cars = cars.map((i: ICar) => {
      const item = new Item(this.wrapper.element, i);

      item.remove = (id) => this.removeCar(id);
      item.update = (id) => this.updateCar(id);

      return item;
    });
  }
}

export { GarageWrapper };
