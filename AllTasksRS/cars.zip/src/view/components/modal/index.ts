import { Template } from '@/view/template';
import { IData } from '@/data/Interfaces/IData';
import style from './index.module.scss';

class Modal extends Template {
  public constructor(parent: HTMLElement, data: IData) {
    super(parent, 'div', style.modal_window);

    new Template(this.element, 'h2', style.modal_title, `Won - ${data.name} | Best time - ${data.time} sec`, {
      color: `${data.color}`,
    });
  }
}

export { Modal };
