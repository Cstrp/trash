import { Template } from '@/view/template';
import { IUniversal } from '@/data/Interfaces/IData';
import { carImg } from '@/data/Utils/_car';

class _Item extends Template {
  public constructor(parent: HTMLElement, winner: IUniversal) {
    super(parent, 'div', 'item');

    const { name, color, wins, time } = winner;

    new Template(this.element, 'div', 'winner_img', `${carImg(color)}`);
    new Template(this.element, 'p', null, `${name}`);
    new Template(this.element, 'p', null, `${color}`);
    new Template(this.element, 'p', null, `${wins}`);
    new Template(this.element, 'p', null, `${time}`);
  }
}

export { _Item };
