import { _Item } from '@/view/components/winners/_index';
import { Template } from '@/view/template';
import { Pagination } from '@/view/components/pagination';
import { ICar } from '@/data/Interfaces/ICar';
import { IWinner } from '@/data/Interfaces/IWinner';
import { IUniversal } from '@/data/Interfaces/IData';
import { car } from '@/data/Api/_car';

class WinnersWrapper extends Template {
  public update: (counter: number) => void = () => {};

  public sortItem: (item: string, order: string) => void = () => {};

  private title: Template;

  private wrapper!: Template;

  public pagination: Pagination;

  public itemList: IWinner[] = [];

  public constructor(parent: HTMLElement) {
    super(parent, 'div', 'wrapper');

    this.title = new Template(this.element, 'h2', 'winners_title');

    this.pagination = new Pagination(this.element);
    this.pagination.updateCounter = (num: number) => this.update(num);

    const itemWrapper = new Template(this.element, 'div', 'item_list_wrapper');

    new Template(itemWrapper.element, 'div', 'item_title-id', '################');
    new Template(itemWrapper.element, 'div', 'item_title- name', 'Name');
    new Template(itemWrapper.element, 'div', 'item_title-color', 'Color');
    const wins = new Template(itemWrapper.element, 'div', 'item_title-wins', 'Wins');

    wins.element.addEventListener('click', () => this.sortHandler(wins.element, 'wins'));

    const time = new Template(itemWrapper.element, 'div', 'item_title-time', 'Time');

    time.element.addEventListener('click', () => this.sortHandler(time.element, 'time'));

    this.wrapper = new Template(this.element, 'div', 'item_wrapper');
  }

  private updTitle(item: string): void {
    this.title.element.innerHTML = `Wins: ${item} cars`;
  }

  public sortHandler(item: Element, type: string) {
    item.classList.toggle('active');

    if (item.classList.contains('active')) {
      this.sortItem(type, 'ASC');
    } else {
      this.sortItem(type, 'DESC');
    }
  }

  public async getCar(id: number): Promise<ICar | null> {
    const [data] = await Promise.all([car(id)]);

    return data;
  }

  public addItem(items: { result: IWinner[]; count: string }): void {
    this.wrapper.element.innerHTML = '';
    this.itemList = items.result;

    let id: number = 1;

    if (items.count) this.updTitle(items.count);

    this.itemList.forEach(async (item: IWinner) => {
      const [i] = await Promise.all([car(item.id)]);

      if (i) {
        const dataItem: IUniversal = {
          id: id++,
          name: i.name,
          color: i.color,
          wins: item.wins,
          time: item.time,
        };

        new _Item(this.wrapper.element, dataItem);
      }
    });
  }
}

export { WinnersWrapper };
