import { Template } from '@/view/template';
import { Button } from '@/view/components/UI/button';

class Pagination extends Template {
  public updateCounter: (counter: number) => void = () => {};

  private pageNumber: number = 1;

  private title: Template;

  public nextBtn: Button;

  public prevBtn: Button;

  public constructor(parent: HTMLElement) {
    super(parent, 'div', 'pagination_wrapper');

    this.title = new Template(this.element, 'h2', 'pagination_title', `Page ${this.pageNumber}`);

    this.prevBtn = new Button(this.element, 'button_prev', 'Prev', true);
    this.prevBtn.onClickBtn = () => this.switch('prev');

    this.nextBtn = new Button(this.element, 'button_next', 'Next');
    this.nextBtn.onClickBtn = () => this.switch('next');
  }

  public updateNextBtn(count: number, totalCount: number, limit: number): void {
    if (count > totalCount / limit) {
      this.nextBtn.setDisable(true);
    } else {
      this.nextBtn.setDisable(false);
    }
  }

  private updatePrevBtn(): void {
    if (this.pageNumber === 1) {
      this.prevBtn.setDisable(true);
    } else {
      this.prevBtn.setDisable(false);
    }
  }

  private switch(count: string) {
    if (count === 'prev') {
      if (this.pageNumber > 1) this.pageNumber -= 1;
    }

    if (count === 'next') this.pageNumber += 1;

    this.title.element.innerHTML = `Page ${this.pageNumber}`;
    this.updateCounter(this.pageNumber);
    this.updatePrevBtn();
  }
}

export { Pagination };
