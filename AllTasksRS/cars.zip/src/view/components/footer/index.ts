import { Template } from '@/view/template';
import style from './index.module.scss';

class Footer extends Template {
  public constructor(parent: HTMLElement) {
    super(parent, 'footer', `footer ${style.wrapper}`);
    const wrapper = new Template(this.element, 'div', style.footerWrapper);
    const footerLogo = new Template(wrapper.element, 'div', 'footer_logo');
    const footerLogoLink = new Template(footerLogo.element, 'a', 'footer_logo-link', null, {
      href: '/cstrp-JSFE2022Q1//#/garage12345',
    });

    new Template(footerLogoLink.element, 'h2', style.footer_logoTitle, 'RSchool © 2022');
    const footerLogoRS = new Template(wrapper.element, 'div', style.footerWrapperLogoRSImg);
    const footerLogoLinkRs = new Template(footerLogoRS.element, 'a', 'footer_rs-link', null, {
      href: 'https://wearecommunity.io/communities/the-rolling-scopes',
    });

    new Template(footerLogoLinkRs.element, 'img', style.footerWrapperLogoRSImg, null, {
      src: 'https://rollingscopes.com/images/logo_rs_text.svg',
    }).element;
    const footerLogoGit = new Template(wrapper.element, 'div', 'footer_logo-git');
    const footerLogoGitLink = new Template(footerLogoGit.element, 'a', style.footerWrapperLogoLink, null, {
      href: 'https://github.com/Cstrp',
    });

    new Template(footerLogoGitLink.element, 'img', style.footerWrapperLogoRSImg, null, {
      src: 'https://upload.wikimedia.org/wikipedia/commons/2/29/GitHub_logo_2013.svg',
    });
  }
}

export { Footer };
