import { Template } from '@/view/template';
import style from './index.module.scss';

class Header extends Template {
  public constructor(parent: HTMLElement) {
    super(parent, 'header', 'header');

    const wrapper = new Template(this.element, 'div', 'wrapper');

    const header = new Template(wrapper.element, 'div', style.header_wrapper);

    const garageBtn = new Template(header.element, 'button', style.header_btn);

    new Template(garageBtn.element, 'a', style.link, 'Garage', { href: '#/garage' });

    const headerLogo = new Template(header.element, 'a', `${style.link}`, '', { href: '/cstrp-JSFE2022Q1/#' });

    new Template(headerLogo.element, 'h2', `${style.header_title} ${style.glitch}`, 'Async race');

    const winnersBtn = new Template(header.element, 'button', style.header_btn);

    new Template(winnersBtn.element, 'a', style.link, 'Winners', {
      href: '#/winners',
    });
  }
}

export { Header };
