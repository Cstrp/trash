import { IInputProps } from '@/data/Interfaces/IInputProps';
import { Template } from '@/view/template';

class Input extends Template implements IInputProps {
  public parent!: Template | HTMLElement;

  public type!: string;

  public className!: string | null;

  public value?: string | null;

  public getValue: (evt: Event) => void = () => {};

  public constructor(parent: HTMLElement, type: string, className?: string, value?: string) {
    super(parent, 'input', 'input');
    this.element.setAttribute('type', type);
    if (className) {
      this.element.classList.add(...className.split(' '));
    }

    if (value) {
      this.element.setAttribute('value', value);
    }

    this.element.addEventListener('input', (evt) => this.getValue(evt));
  }
}

export { Input };
