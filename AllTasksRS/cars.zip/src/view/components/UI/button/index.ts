import { ButtonProps, content } from '@/data/Interfaces/IButtonProps';
import { ISwitcher } from '@/data/Interfaces/ISwitcher';
import { Template } from '@/view/template';

class Button extends Template implements ButtonProps {
  public onClickBtn: () => void = () => {};

  public constructor(parent: HTMLElement, className?: string, value?: string, state: boolean = false) {
    super(parent, 'button', 'btn', value);
    if (className) {
      this.element.classList.add(...className.split(' '));
    }

    this.element.addEventListener('click', () => this.onClickBtn());

    if (state) {
      this.setDisable(true);
    }
  }

  parent!: Template | HTMLElement;

  className?: content;

  text?: content;

  success?: ISwitcher;

  public setDisable(success: boolean = false): void {
    this.element.toggleAttribute('disabled', success);
  }

  public removeDisable(): void {
    this.element.removeAttribute('disabled');
  }
}

export { Button };
