import { ICar } from '@/data/Interfaces/ICar';
import { IWinner } from '@/data/Interfaces/IWinner';

interface IData {
  id: number;
  name: string;
  color: string;
  speed: number;
  wins: number;
  time: number;
}

interface IUniversal extends ICar, IWinner {}

export { IData, IUniversal };
