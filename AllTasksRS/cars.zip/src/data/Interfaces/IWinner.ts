interface IWinner {
  id: number;
  time: number;
  wins: number;
}

export { IWinner };
