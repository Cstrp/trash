interface ISwitcher {
  success: boolean;
}

export { ISwitcher };
