interface ICar {
  id: number;
  name: string;
  color: string;
}

interface ICreateCar {
  name: string;
  color: string;
}

interface IUpdateCar {
  id?: number;
  name: string;
  color: string;
}

export { ICar, ICreateCar, IUpdateCar };
