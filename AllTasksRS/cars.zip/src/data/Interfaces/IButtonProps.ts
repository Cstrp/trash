import { ISwitcher } from '@/data/Interfaces/ISwitcher';
import { Template } from '@/view/template';

type content = string | null;

interface ButtonProps {
  parent: Template | HTMLElement;
  className?: content;
  text?: content;
  success?: ISwitcher;
  onClickBtn: () => void;
}

export { ButtonProps, content };
