import { Template } from '@/view/template';

interface IInputProps {
  parent: Template | HTMLElement;
  type: string;
  className?: string | null;
  value?: string | null;
}

export { IInputProps };
