interface IEngine {
  velocity: number;
  distance: number;
}

export { IEngine };
