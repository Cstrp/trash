import axios from 'axios';
import { winners } from '@/data/Utils/helper';
import { IWinner } from '@/data/Interfaces/IWinner';

const allWinners = async (
  page: number,
  sort: string = 'time',
  order: string = 'ASC',
  limit: number = 10,
): Promise<{ result: Array<IWinner>; count: string }> => {
  try {
    const data = await fetch(`${winners}?_page=${page}&_limit=${limit}&_sort=${sort}&_order=${order}`);
    const result = await data.json();

    return { result: result, count: data.headers.get('X-Total-Count') || '0' };
  } catch (error) {
    throw new Error(`Error in all winners: ${error}`);
  }
};

const winner = async (id: number): Promise<{ status: number; result: IWinner }> => {
  try {
    const data = await fetch(`${winners}/${id}`);
    const result: IWinner = await data.json();

    return { status: data.status, result: result };
  } catch (error) {
    throw new Error(`Error in winner: ${error}`);
  }
};

const createWinner = async (_data: IWinner): Promise<number> => {
  const data = await axios.post(`${winners}`, _data).catch((error) => {
    throw new Error(`Error in create winner: ${error}`);
  });

  return data.status;
};

const updateWinner = async (_data: IWinner): Promise<void> => {
  await axios.put(`${winners}/${_data.id}`, _data).catch((error) => {
    throw new Error(`Error in update winner: ${error}`);
  });
};

const removeWinner = async (id: number): Promise<void> => {
  await axios
    .delete(`${winners}/${id}`, {
      headers: {
        'Content-Type': 'application/json',
      },
    })
    .catch((error) => {
      throw new Error(`Error in remove winner: ${error}`);
    });
};

export { allWinners, winner, createWinner, updateWinner, removeWinner };
