import axios from 'axios';
import { Server_Response } from '@/data/Enum';
import { garage } from '@/data/Utils/helper';
import { ICar, ICreateCar, IUpdateCar } from '@/data/Interfaces/ICar';

const allCars = async (page: number = 1, limit: number = 7): Promise<{ cars: Array<ICar>; count: string } | null> => {
  try {
    const data = await fetch(`${garage}?_page=${page}&_limit=${limit}`);
    const result: ICar[] = await data.json();

    if (data.status === Server_Response.success) {
      return { cars: result, count: data.headers.get('X-Total-Count') || '0' };
    }

    return null;
  } catch (error) {
    throw new Error(`Error in allCars: ${error}`);
  }
};

const car = async (id: number): Promise<ICar | null> => {
  const data = await axios.get(`${garage}/${id}`).catch((error) => {
    throw new Error(`Error in car: ${error}`);
  });

  const result: ICar = await data.data;

  if (data.status === Server_Response.success) {
    return result;
  }

  return null;
};

const updateCar = async (_data: IUpdateCar): Promise<void> => {
  await axios.put(`${garage}/${_data.id}`, _data).catch((error) => {
    throw new Error(`Error in updateCar: ${error}`);
  });
};

const createCar = async (
  _data: ICreateCar,
  callback?: Array<{ name: string; color: string }> | undefined,
): Promise<void> => {
  await axios.post(`${garage}`, _data).catch((error) => {
    throw new Error(`Error in createCar: ${error}`);
  });
  if (callback) {
    callback.forEach((item) => {
      const car = {
        name: item.name,
        color: item.color,
      };

      createCar(car);
    });
  }
};

const removeCar = async (id: number): Promise<void> => {
  await axios.delete(`${garage}/${id}`).catch((error) => {
    throw new Error(`Error in removeCar: ${error}`);
  });
};

export { allCars, car, updateCar, createCar, removeCar };
