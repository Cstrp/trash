import { Status } from '@/data/Enum';
import { engine } from '@/data/Utils/helper';
import { IEngine } from '@/data/Interfaces/IEngine';

const startEngine = async (id: number): Promise<{ status: number; result: IEngine }> => {
  try {
    const data = await fetch(`${engine}?id=${id}&status=${Status.start}`, {
      method: 'PATCH',
    });
    const response: IEngine = await data.json();

    return { status: data.status, result: response };
  } catch (error) {
    throw new Error(`Oops, something went wrong: ${error}`);
  }
};

const stopEngine = async (id: number): Promise<{ status: number; result: IEngine }> => {
  try {
    const data = await fetch(`${engine}?id=${id}&status=${Status.stop}`, {
      method: 'PATCH',
    });
    const response: IEngine = await data.json();

    return { status: data.status, result: response };
  } catch (error) {
    throw new Error(`Oops, something went wrong: ${error}`);
  }
};

const switchMode = async (id: number): Promise<number> => {
  try {
    const data = await fetch(`${engine}?id=${id}&status=${Status.drive}`, {
      method: 'PATCH',
    });

    return data.status;
  } catch (error) {
    throw new Error(`Oops, something went wrong: ${error}`);
  }
};

export { startEngine, stopEngine, switchMode };
