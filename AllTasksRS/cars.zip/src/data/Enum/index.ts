const enum AppPage {
  garage = '/garage',
  winners = '/winners',
}

const enum Status {
  start = 'started',
  stop = 'stopped',
  drive = 'drive',
}

enum Server_Response {
  success = 200,
  server_err = 500,
}

export { AppPage, Status, Server_Response };
