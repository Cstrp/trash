/* eslint-disable max-len */
// eslint-disable-next-line max-lines-per-function
export const carImg = (color: string): string => `
<svg
         xmlns="http://www.w3.org/2000/svg"
         viewBox="0 0 1280.000000 307.000000" width="150.000000pt" height="210.000000pt"
         preserveAspectRatio="xMidYMid meet"
         style="fill: ${color};"
>
        <defs
           id="defs4838">
          <inkscape:path-effect
             effect="spiro"
             id="path-effect4248"
             is_visible="true" />
          <inkscape:path-effect
             effect="skeletal"
             id="path-effect4250"
             is_visible="true"
             pattern="M 0,5 C 0,2.24 2.24,0 5,0 7.76,0 10,2.24 10,5 10,7.76 7.76,10 5,10 2.24,10 0,7.76 0,5 Z"
             copytype="single_stretched"
             prop_scale="1"
             scale_y_rel="false"
             spacing="0"
             normal_offset="0"
             tang_offset="0"
             prop_units="false"
             vertical_pattern="false"
             fuse_tolerance="0" />
          <inkscape:path-effect
             effect="spiro"
             id="path-effect4254"
             is_visible="true" />
          <inkscape:path-effect
             effect="skeletal"
             id="path-effect4256"
             is_visible="true"
             pattern="M 0,5 C 0,2.24 2.24,0 5,0 7.76,0 10,2.24 10,5 10,7.76 7.76,10 5,10 2.24,10 0,7.76 0,5 Z"
             copytype="single_stretched"
             prop_scale="1"
             scale_y_rel="false"
             spacing="0"
             normal_offset="0"
             tang_offset="0"
             prop_units="false"
             vertical_pattern="false"
             fuse_tolerance="0" />
          <inkscape:path-effect
             effect="spiro"
             id="path-effect4300"
             is_visible="true" />
          <inkscape:path-effect
             effect="skeletal"
             id="path-effect4302"
             is_visible="true"
             pattern="M 0,5 C 0,2.24 2.24,0 5,0 7.76,0 10,2.24 10,5 10,7.76 7.76,10 5,10 2.24,10 0,7.76 0,5 Z"
             copytype="single_stretched"
             prop_scale="1"
             scale_y_rel="false"
             spacing="0"
             normal_offset="0"
             tang_offset="0"
             prop_units="false"
             vertical_pattern="false"
             fuse_tolerance="0" />
          <inkscape:path-effect
             effect="spiro"
             id="path-effect4224"
             is_visible="true" />
          <inkscape:path-effect
             effect="skeletal"
             id="path-effect4226"
             is_visible="true"
             pattern="M 0,5 C 0,2.24 2.24,0 5,0 7.76,0 10,2.24 10,5 10,7.76 7.76,10 5,10 2.24,10 0,7.76 0,5 Z"
             copytype="single_stretched"
             prop_scale="1"
             scale_y_rel="false"
             spacing="0"
             normal_offset="0"
             tang_offset="0"
             prop_units="false"
             vertical_pattern="false"
             fuse_tolerance="0" />
          <inkscape:path-effect
             effect="spiro"
             id="path-effect5035"
             is_visible="true" />
          <inkscape:path-effect
             effect="skeletal"
             id="path-effect5037"
             is_visible="true"
             pattern="m 1.4613957,16.457685 c 0,-2.76 2.24,-5 5,-5 2.76,0 5.0000003,2.24 5.0000003,5 0,2.76 -2.2400003,5.000001 -5.0000003,5.000001 -2.76,0 -5,-2.240001 -5,-5.000001 z"
             copytype="single_stretched"
             prop_scale="1"
             scale_y_rel="false"
             spacing="0"
             normal_offset="0"
             tang_offset="0"
             prop_units="false"
             vertical_pattern="false"
             fuse_tolerance="0" />
          <inkscape:path-effect
             effect="spiro"
             id="path-effect5041"
             is_visible="true" />
          <inkscape:path-effect
             effect="skeletal"
             id="path-effect5043"
             is_visible="true"
             pattern="m 0,15 c 0,-2.76 2.24,-5 5,-5 2.76,0 5,2.24 5,5 0,2.76 -2.24,5 -5,5 -2.76,0 -5,-2.24 -5,-5 z"
             copytype="single_stretched"
             prop_scale="1"
             scale_y_rel="false"
             spacing="0"
             normal_offset="0"
             tang_offset="0"
             prop_units="false"
             vertical_pattern="false"
             fuse_tolerance="0" />
        </defs>
        <sodipodi:namedview
           id="base"
           pagecolor="#ffffff"
           bordercolor="#666666"
           borderopacity="1.0"
           inkscape:pageopacity="0.0"
           inkscape:pageshadow="2"
           inkscape:zoom="0.94597854"
           inkscape:cx="218.55437"
           inkscape:cy="568.11165"
           inkscape:document-units="px"
           inkscape:current-layer="layer1"
           showgrid="false"
           inkscape:window-width="1920"
           inkscape:window-height="1178"
           inkscape:window-x="-8"
           inkscape:window-y="-8"
           inkscape:window-maximized="1" />
        <metadata
           id="metadata4841">
          <rdf:RDF>
            <cc:Work
               rdf:about="">
              <dc:format>image/svg+xml</dc:format>
              <dc:type
                 rdf:resource="https://purl.org/dc/dcmitype/StillImage" />
              <dc:title />
            </cc:Work>
          </rdf:RDF>
        </metadata>
        <g
           inkscape:label="Ebene 1"
           inkscape:groupmode="layer"
           id="layer1">
          <g
             style="display:inline"
             id="g4290"
             transform="translate(-12.36079,264.97686)">
            <path
               inkscape:connector-curvature="0"
               inkscape:original-d="m 92.067933,276.40059 614.479237,0"
               inkscape:path-effect="#path-effect4224;#path-effect4226"
               id="path4221"
               d="m 92.067933,276.40059 c 0,-2.76 137.643347,-5 307.239617,-5 169.59627,0 307.23962,2.24 307.23962,5 0,2.76 -137.64335,5 -307.23962,5 -169.59627,0 -307.239617,-2.24 -307.239617,-5 z"
               style="fill:${color};fill-rule:evenodd;stroke:none;stroke-width:1px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
               sodipodi:nodetypes="cc" />
            <g
               style="stroke:#fefefe;stroke-width:2.94644451;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
               transform="matrix(-1.3575685,0,0,1.3575684,18.860032,-405.52962)"
               id="g4989">
              <ellipse
                 ry="37.862938"
                 rx="38.66853"
                 cy="483.14856"
                 cx="-439.95117"
                 id="ellipse4991"
                 style="opacity:1;fill:${color};fill-opacity:1;stroke:#fefefe;stroke-width:2.94644451;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1" />
              <circle
                 r="25.146713"
                 style="opacity:1;fill:${color};fill-opacity:1;stroke:#fefefe;stroke-width:2.94644451;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1"
                 id="circle4993"
                 cx="-439.95111"
                 cy="483.14856" />
            </g>
            <g
               style="stroke:${color};stroke-width:2.94644451;stroke-miterlimit:4;stroke-dasharray:none;stroke-opacity:1"
               id="g5011"
               transform="matrix(-1.3575685,0,0,1.3575684,-377.23136,-402.778)">
              <ellipse
                 style="opacity:1;fill:${color};fill-opacity:1;stroke:#fefefe;stroke-width:2.94644451;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1"
                 id="ellipse5013"
                 cx="-431.11176"
                 cy="483.14856"
                 rx="38.66853"
                 ry="37.862938" />
              <circle
                 cy="483.14856"
                 cx="-431.11169"
                 id="circle5015"
                 style="opacity:1;fill:${color};fill-opacity:1;stroke:#fefefe;stroke-width:2.94644451;stroke-linecap:round;stroke-linejoin:miter;stroke-miterlimit:4;stroke-dasharray:none;stroke-dashoffset:0;stroke-opacity:1"
                 r="25.146713" />
            </g>
            <path
               sodipodi:nodetypes="cssssc"
               inkscape:connector-curvature="0"
               inkscape:original-d="m 67.954902,146.98614 c 2.922791,0.7307 -3.653487,46.03398 57.725138,24.11304 61.37862,-21.92094 80.42741,-35.34097 122.75724,-26.88141 46.9709,9.38707 172.46135,-12.79374 190.36563,-9.49907 21.23312,3.90724 29.22792,14.61395 46.03398,28.49721 16.80605,13.88326 38.72697,17.19025 38.72697,17.19025"
               inkscape:path-effect="#path-effect5035;#path-effect5037"
               id="path5033"
               d="m 67.954902,146.98614 c 0.498804,-0.63492 5.298456,2.98332 14.930323,7.84374 9.387722,4.73721 24.310175,10.98626 43.216955,12.92249 0,-1e-5 10e-6,0 10e-6,0 18.11929,1.89005 38.01366,-0.34687 61.23391,-6.89941 19.91636,-5.64648 36.98135,-12.81244 59.40463,-21.21823 15.46618,-5.81892 32.0619,-11.57165 49.20612,-16.14938 15.75952,-4.208 31.26007,-7.2326 46.72591,-8.75775 37.79393,-3.75788 71.38176,2.57829 97.93213,16.42094 12.92847,6.79825 39.11335,25.5367 45.65718,29.62178 22.5438,14.07572 37.78115,18.12833 37.30179,19.63584 -0.14437,0.45404 -16.06014,-1.64501 -40.15215,-14.74466 -3.91908,-2.1313 -37.69501,-23.16526 -46.41078,-27.37264 -25.3751,-12.36553 -57.13116,-17.55536 -93.33703,-13.79965 -14.83816,1.55176 -29.7855,4.54101 -45.13258,8.65573 -16.67201,4.46995 -33.03752,10.06347 -48.39749,15.65587 -22.11714,8.08295 -39.99486,15.19975 -60.48859,20.54405 -24.10616,6.31704 -45.35507,7.89595 -64.38735,5.10113 0,0 -2e-5,0 -2e-5,0 -42.184654,-6.27005 -56.588205,-28.36967 -57.302968,-27.45985 z"
               style="opacity:1;fill:${color};fill-rule:evenodd;stroke:none;stroke-width:1px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1" />
            <path
               inkscape:connector-curvature="0"
               inkscape:original-d="m 75.992579,276.40059 c 0,0 -5.114885,-56.53303 2.922791,-63.84001 8.037677,-7.30698 24.11303,-29.22792 41.64978,-32.88141 17.53675,-3.65349 19.72884,-11.69116 56.99443,-8.76837 37.26559,2.92279 116.18097,12.42186 154.90795,12.42186 38.72699,0 127.14143,0 174.63679,-1.46139 47.49537,-1.4614 92.79863,-0.92279 116.18097,6.38418 23.38233,7.30698 37.99629,8.03768 51.87955,12.42187 13.88325,4.38419 21.92093,6.57628 32.8814,18.99814 10.96047,12.42187 18.94171,13.94626 16.74962,27.82952 -2.1921,13.88326 -5.59706,28.89561 -5.59706,28.89561"
               inkscape:path-effect="#path-effect5041;#path-effect5043"
               id="path5039"
               d="m 75.992579,276.40059 c -0.246475,0.12044 -2.109519,-2.29131 -4.26562,-7.6439 -2.073413,-5.14733 -4.642916,-13.80805 -4.449995,-24.74204 0.170391,-9.55711 2.522095,-21.36219 9.249889,-32.9054 4e-6,0 9e-6,-2e-5 9e-6,-2e-5 8.338147,-14.21354 22.892215,-27.08875 42.759508,-34.81142 17.54761,-6.82671 36.77701,-9.21971 58.22612,-9.58855 0,0 3e-5,0 3e-5,0 25.02953,-0.47834 50.06895,1.41464 78.04027,4.29182 23.80413,2.44096 51.55354,5.81402 77.22839,7.39264 18.16073,1.12559 36.5615,1.47516 55.53399,1.37459 6.83201,-0.0362 115.52236,-2.6348 118.73121,-2.66043 0,0 3e-5,1e-5 3e-5,1e-5 43.58846,-0.36153 81.25237,1.62084 116.81997,7.2022 0,0 3e-5,1e-5 3e-5,1e-5 19.60301,3.06525 36.68465,7.04634 52.48122,13.22068 13.56737,5.28088 24.74332,11.85369 33.53455,20.12688 0,0 0,2e-5 0,2e-5 9.95172,9.32798 15.23487,19.89304 16.80906,29.48651 1.59836,10.00004 -0.95302,18.17107 -3.04039,22.68776 -2.21621,4.79548 -4.26516,6.68863 -4.45205,6.56864 -0.37884,-0.24323 1.07735,-2.50778 2.59134,-7.293 1.42948,-4.5181 3.1141,-12.31806 1.11034,-21.24182 -1.89903,-8.64675 -7.21948,-17.82945 -16.69016,-26.1725 -10e-6,0 -2e-5,-1e-5 -2e-5,-1e-5 -8.43473,-7.39957 -19.07938,-13.10779 -32.22825,-17.8694 -15.35353,-5.53466 -31.91459,-8.94934 -51.27783,-11.62305 0,0 -2e-5,0 -2e-5,0 -35.1864,-4.8389 -72.18863,-6.26251 -115.54191,-5.56616 0,1e-5 -3e-5,1e-5 -3e-5,1e-5 -29.17592,0.4777 -85.36908,2.95898 -118.79529,3.12828 -19.13127,0.0969 -37.7701,-0.29242 -56.21309,-1.49134 -26.21105,-1.71666 -53.8205,-5.26081 -77.60385,-7.92816 -27.8567,-3.11527 -52.39689,-5.30768 -76.94339,-5.2311 0,0 -2e-5,1e-5 -2e-5,1e-5 -20.9937,0.10644 -39.22686,1.88542 -55.76269,7.94818 -18.6269,6.83492 -32.453752,18.13568 -40.540052,30.9514 0,0 -5e-6,1e-5 -5e-6,1e-5 -6.580152,10.35764 -9.305369,21.22592 -9.982939,30.18786 -0.775624,10.23212 0.999723,18.70312 2.396884,23.88828 1.45399,5.39606 2.67073,8.11903 2.274761,8.31251 z"
               style="opacity:1;fill:${color};fill-rule:evenodd;stroke:none;stroke-width:1px;stroke-linecap:butt;stroke-linejoin:miter;stroke-opacity:1"
               sodipodi:nodetypes="csssssssssc" />
          </g>
        </g>
      </svg>`;
